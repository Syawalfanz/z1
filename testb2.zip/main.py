import mysql.connector #type:ignore
from tkinter import *
from tkinter import ttk, messagebox

# Function to create the database and table
def create_database_and_table():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password=""
        )
        cursor = connection.cursor()
        
        # Create database if not exists
        cursor.execute("CREATE DATABASE IF NOT EXISTS pbt_database")
        
        # Use the database
        cursor.execute("USE pbt_database")
        
        # Create table if not exists
        cursor.execute("CREATE TABLE IF NOT EXISTS graduates (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), matric_number VARCHAR(255), program VARCHAR(255), gender VARCHAR(255), telephone_number VARCHAR(255), email VARCHAR(255), great_gatsby_theme INT DEFAULT 0, classic_graduation_theme INT DEFAULT 0, tropical_luau_theme INT DEFAULT 0)")
        
        connection.commit()
        cursor.close()
        connection.close()
        print("Success", "Database and Table created successfully!")
    except mysql.connector.Error as error:
        print("Error", f"Failed to create database and table: {error}")

# Function to register a graduate and vote for a theme
def register_and_vote():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="pbt_database"
        )
        cursor = connection.cursor()

        name = name_entry.get()
        matric_number = matric_entry.get()
        program = program_entry.get()
        gender = gender_var.get()  # Get selected gender from the dropdown
        telephone_number = telephone_entry.get()
        email = email_entry.get()
        vote_theme = vote_theme_var.get()

        # Data validation
        if not all([name, matric_number, program, telephone_number, email]):
            raise ValueError("All fields are required.")

        # Validate gender selection
        if gender == "Select":
            raise ValueError("Please select a gender.")

        # Validate vote theme selection
        if vote_theme == "Select":
            raise ValueError("Please select a theme.")

        # Register graduate
        sql_register = "INSERT INTO graduates (name, matric_number, program, gender, telephone_number, email) VALUES (%s, %s, %s, %s, %s, %s)"
        values_register = (name, matric_number, program, gender, telephone_number, email)
        cursor.execute(sql_register, values_register)
        
        # Vote for theme
        sql_vote = f"UPDATE graduates SET {vote_theme.lower().replace(' ', '_')} = {vote_theme.lower().replace(' ', '_')} + 1 WHERE matric_number = %s"
        cursor.execute(sql_vote, (matric_number,))

        connection.commit()
        cursor.close()
        connection.close()

        # Clear form fields after successful registration and voting
        name_entry.delete(0, END)
        matric_entry.delete(0, END)
        program_entry.delete(0, END)
        gender_var.set("Select")
        telephone_entry.delete(0, END)
        email_entry.delete(0, END)
        vote_theme_var.set("Select")

        messagebox.showinfo("Success", "Graduate registered and vote recorded successfully!")
    except mysql.connector.Error as error:
        messagebox.showerror("Error", f"Failed to register graduate or vote: {error}")
    except ValueError as value_error:
        messagebox.showerror("Error", f"Invalid data: {value_error}")
    except Exception as ex:
        messagebox.showerror("Error", f"An unexpected error occurred: {ex}")



# GUI setup
root = Tk()
root.title("PP University Convocation Theme Selection")

# Create database and table
create_database_and_table()

# Styling
style = ttk.Style()
style.theme_use("clam")  # Use the clam theme for a modern look
style.configure("TLabel", background="#f0f0f0", foreground="#333")  # Configure label style
style.configure("TButton", background="#4CAF50", foreground="white")  # Configure button style
style.configure("TMenubutton", background="white", foreground="#333")  # Configure menubutton style
style.configure("TEntry", background="white", foreground="#333")  # Configure entry style

# Registration Form
frame_registration = ttk.Frame(root, padding=(20, 10))
frame_registration.grid(row=0, column=0, padx=20, pady=20)

ttk.Label(frame_registration, text="Name:").grid(row=0, column=0, sticky="w")
ttk.Label(frame_registration, text="Matric Number:").grid(row=1, column=0, sticky="w")
ttk.Label(frame_registration, text="Program:").grid(row=2, column=0, sticky="w")
ttk.Label(frame_registration, text="Gender:").grid(row=3, column=0, sticky="w")
ttk.Label(frame_registration, text="Telephone Number:").grid(row=4, column=0, sticky="w")
ttk.Label(frame_registration, text="Email:").grid(row=5, column=0, sticky="w")

name_entry = ttk.Entry(frame_registration)
name_entry.grid(row=0, column=1, padx=5, pady=5)
matric_entry = ttk.Entry(frame_registration)
matric_entry.grid(row=1, column=1, padx=5, pady=5)
program_entry = ttk.Entry(frame_registration)
program_entry.grid(row=2, column=1, padx=5, pady=5)

# Gender dropdown
gender_var = StringVar()
gender_var.set("Select")  # Default gender selection
gender_menu = OptionMenu(frame_registration, gender_var, "Male", "Female")
gender_menu.grid(row=3, column=1, padx=5, pady=5)

telephone_entry = ttk.Entry(frame_registration)
telephone_entry.grid(row=4, column=1, padx=5, pady=5)
email_entry = ttk.Entry(frame_registration)
email_entry.grid(row=5, column=1, padx=5, pady=5)

# Voting Section
frame_voting = ttk.Frame(root, padding=(20, 10))
frame_voting.grid(row=1, column=0, padx=20, pady=20)

ttk.Label(frame_voting, text="Vote for Theme:").grid(row=0, column=0, sticky="w")
vote_theme_var = StringVar()
vote_theme_var.set("Select")  # Default theme selection
vote_theme_menu = ttk.OptionMenu(frame_voting, vote_theme_var, "Select", "Great Gatsby Theme", "Classic Graduation Theme", "Tropical Luau Theme")
vote_theme_menu.grid(row=0, column=1, padx=5, pady=5, sticky="w")

# Button to register and vote
register_vote_button = ttk.Button(root, text="Register & Vote", command=register_and_vote)
register_vote_button.grid(row=2, column=0, pady=20)

root.mainloop()
